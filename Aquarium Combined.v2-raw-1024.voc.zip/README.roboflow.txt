
Aquarium Combined - v2 raw-1024
==============================

This dataset was exported via roboflow.ai on November 18, 2020 at 7:54 PM GMT

It includes 638 images.
Creatures are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 1024x1024 (Fit within)

No image augmentation techniques were applied.


